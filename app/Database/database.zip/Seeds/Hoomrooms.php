<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Hoomrooms extends Seeder
{
    public function run()
    {
        //
    }
}
