<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Classes extends Seeder
{
    public function run()
    {
        //
    }
}
