<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Privileges extends Seeder
{
    public function run()
    {
        //
    }
}
